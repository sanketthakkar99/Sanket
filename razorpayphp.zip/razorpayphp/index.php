<?php
//require('Database/db-config.php');
if( !empty($_GET['err']))
{
$err=$_GET['err'];
} ?>

<!DOCTYPE html>
<html>
<head lang="en">
    <title>Razorpay Demo</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="http://yegor256.github.io/tacit/tacit.min.css"/>
</head>
<body>
    <form id="checkout-selection" method="POST" action="pay.php">
      <label>Name: </label><br/>
      <input type="text" name="name" pattern="[A-Za-z]{2,}" title="Enter valid name" value="" required>
      <br/>
      <label>E-mail:</label><br/>
      <input type="email" name="email" required="required" value="">
      <br/>
      <label>Contact No:</label><br/>
      <input type="tel" name="phone"  pattern="[6-9]{1}[0-9]{9}" title="Enter Valid Phone Number" required="required" value="" required="required"><br/>
      <label>Amount To Pay:</label><br/>
      <input type="text" name="amount" value="2500" readonly="readonly"><br/>
      <label>Address:</label><br/>
      <textarea name="address" rows="5" cols="40"></textarea><br/>
        <input type="radio" name="checkout" checked="checked" value="automatic" required>Pay now
        <input type="radio" name="checkout" value="manual">Pay With RazorPay<br>
        <input type="submit" name="submit" value="submit">
    </form>
    </body>

</html>
