<?php
session_start();
extract($_POST);
$_SESSION['data'] = $_POST;
if($_POST['submit']!= '' && $_POST['submit']== 'Submit')
{
  $con = mysqli_connect('localhost','root','','razorpay_db');
  $insert = "INSERT INTO payment(name,email,contact,amount,address,order_id,payment_id,payment_status,method)VALUES('".$name."','".$email."','".$phone."','".$amount."','".$address."','".$razorpayOrderId."','','','".$checkout."')";
  $sql = mysqli_query($con,$insert);
  if(!$sql)
  {
    header("location:index.php");
  }
  else
  {
          if($_POST['checkout']=='automatic')
          {
              header("location:pay.php?checkout=automatic");
          }
          if($_POST['checkout']=='manual')
          {
            header("location:pay.php?checkout=manual");
          }
  }
}


?>
