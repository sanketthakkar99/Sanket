-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2018 at 01:22 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `razorpay_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `payment_id` varchar(255) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `method` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `name`, `email`, `contact`, `amount`, `address`, `order_id`, `payment_id`, `payment_status`, `method`) VALUES
(17, 'arvind', 'pristinit.test@gmail.com', '8866650846', '250000', 'a/15 shree mahashakti apatment, Maninagar', 'order_9qn2EuMqbxqyKH', 'pay_9qn30VFvXpuM67', 'complete', 'manual'),
(16, 'sanket', 'sanketthakkar96@gmail.com', '8866650841', '250000', 'a/15 shree mahashakti apartment,ahmedabad', 'order_9qmzh1cOG36SvZ', 'pay_9qmzqL0kgaHrq5', 'complete', 'automatic'),
(18, 'abc', 'abc@gmail.com', '8866650847', '250000', 'aaaaaaaaaaaaaeftby6nun7', 'order_9qn7wcZhsFkrSd', 'pay_9qn8xDUaH7SsN4', 'complete', 'automatic'),
(19, 'arvind', 'arvindpatel@gmail.com', '8866650849', '250000', 'efevgthbtnyn', 'order_9qnIG9jfQUAp8h', 'pay_9qnJuz5vlIRs6A', 'complete', 'manual');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
